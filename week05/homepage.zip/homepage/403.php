<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>403 Forbidden</title>
    <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico">
</head>
<body>
    <h1>403 Forbidden</h1>
    <p>You are not authorized to access this resource.</p>
</body>
</html>
