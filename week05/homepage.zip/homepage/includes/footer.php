    </div>
    <footer class="text-center mt-5 mb-3">
        <hr>
        <small>&copy; 2025 Simulacra Corp. All Rights Reserved.</small>
    </footer>
</body>
</html>